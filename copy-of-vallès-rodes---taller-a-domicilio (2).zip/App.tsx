
import React from 'react';
import Header from './components/Header';
import Hero from './components/Hero';
import Services from './components/Services';
import Coverage from './components/Coverage';
import Testimonials from './components/Testimonials';
import Faq from './components/Faq';
import Cta from './components/Cta';
import Footer from './components/Footer';
import StickyMobileActions from './components/StickyMobileActions';
import ChatWidget from './components/ChatWidget';
import { PHONE_NUMBER } from './constants';
import BookingSection from './components/BookingSection';

const App: React.FC = () => {
  const phoneUrl = `tel:${PHONE_NUMBER}`;

  return (
    <>
      <StickyMobileActions phoneUrl={phoneUrl} />
      <Header phoneUrl={phoneUrl} />
      <main>
        <Hero />
        <Services />
        <Coverage />
        <Testimonials />
        <BookingSection />
        <Faq />
        <Cta />
      </main>
      <Footer phoneUrl={phoneUrl} />
      <ChatWidget />
    </>
  );
};

export default App;
