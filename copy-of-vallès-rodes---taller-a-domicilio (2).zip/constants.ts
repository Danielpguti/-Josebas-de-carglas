
export const PHONE_NUMBER = '+34612345678'; // Placeholder phone number
