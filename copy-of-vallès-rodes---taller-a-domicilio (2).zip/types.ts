export interface ToolCall {
  id: string;
  type: 'function';
  function: {
    name: string;
    arguments: string;
  };
}

export interface Message {
  role: 'user' | 'assistant' | 'system' | 'tool';
  content: string | null;
  name?: string; // For tool role
  tool_call_id?: string; // For tool role
  tool_calls?: ToolCall[]; // For assistant role
}