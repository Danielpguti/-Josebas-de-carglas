
import React, { useState } from 'react';
import { generateGoogleCalendarLink } from '../utils';

interface FormData {
    name: string;
    phone: string;
    email: string;
    city: string;
    service: 'mantenimiento' | 'neumaticos' | 'recogida' | '';
    model: string;
    plate: string;
    tireSize: string;
    date: string;
    start: string;
    end: string;
    address: string;
    replacementCar: boolean;
    accept: boolean;
}

interface FormErrors {
    [key: string]: string;
}

const BookingForm: React.FC = () => {
    const [formData, setFormData] = useState<FormData>({
        name: '', phone: '', email: '', city: '', service: '', model: '', plate: '',
        tireSize: '', date: '', start: '', end: '', address: '', replacementCar: false, accept: false
    });
    const [errors, setErrors] = useState<FormErrors>({});
    const [isSubmitted, setIsSubmitted] = useState(false);
    const [calendarLink, setCalendarLink] = useState('');

    const validate = (): FormErrors => {
        const newErrors: FormErrors = {};
        if (!formData.name) newErrors.name = 'El nombre es obligatorio.';
        if (!formData.phone) newErrors.phone = 'El teléfono es obligatorio.';
        if (!formData.city) newErrors.city = 'El municipio es obligatorio.';
        if (!formData.service) newErrors.service = 'Debes seleccionar un servicio.';
        if (!formData.date) newErrors.date = 'La fecha es obligatoria.';
        if (new Date(formData.date) < new Date(new Date().toDateString())) newErrors.date = 'La fecha no puede ser en el pasado.';
        if (!formData.start) newErrors.start = 'La hora de inicio es obligatoria.';
        if (!formData.end) newErrors.end = 'La hora de fin es obligatoria.';
        if (formData.start && formData.end) {
             const [sh, sm] = formData.start.split(':').map(Number);
             const [eh, em] = formData.end.split(':').map(Number);
             const minutes = (eh*60+em) - (sh*60+sm);
             if (minutes < 360) newErrors.end = 'La franja horaria debe ser de al menos 6 horas.';
        }
        if (!formData.address) newErrors.address = 'La dirección es obligatoria.';
        if (!formData.accept) newErrors.accept = 'Debes aceptar los términos.';
        return newErrors;
    };

    const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
        const { name, value, type } = e.target;
        const checked = (e.target as HTMLInputElement).checked;
        setFormData(prev => ({ ...prev, [name]: type === 'checkbox' ? checked : value }));
    };

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        const validationErrors = validate();
        setErrors(validationErrors);

        if (Object.keys(validationErrors).length === 0) {
            console.log('Formulario enviado:', formData);
            const link = generateGoogleCalendarLink({
                nombre_cliente: formData.name,
                tipo_servicio: formData.service || 'mantenimiento',
                marca_coche: formData.model.split(' ')[0] || '',
                modelo_coche: formData.model.split(' ').slice(1).join(' ') || '',
                matricula_coche: formData.plate,
                ubicacion_servicio: formData.address,
                fecha_preferida: formData.date,
                hora_preferida: `${formData.start} - ${formData.end}`
            });
            setCalendarLink(link);
            setIsSubmitted(true);
        }
    };
    
    if (isSubmitted) {
        return (
            <div className="text-center p-8 bg-emerald-50 rounded-2xl border border-emerald-200">
                <h3 className="text-xl font-bold text-emerald-800">¡Reserva enviada con éxito!</h3>
                <p className="mt-2 text-emerald-700">Gracias, {formData.name}. Nos pondremos en contacto contigo pronto para confirmar todos los detalles.</p>
                <a 
                    href={calendarLink} 
                    target="_blank" 
                    rel="noopener noreferrer"
                    className="mt-4 inline-flex items-center gap-2 px-5 py-3 rounded-xl bg-slate-900 text-white font-semibold"
                >
                    Añadir a Google Calendar
                </a>
            </div>
        );
    }

    return (
        <form onSubmit={handleSubmit} className="grid grid-cols-1 md:grid-cols-2 gap-x-6 gap-y-4" noValidate>
             <p className="md:col-span-2 text-sm text-slate-600">Los campos con <span className="text-red-500">*</span> son obligatorios.</p>
            <div>
                <label className="block text-sm font-semibold">Nombre y apellidos <span className="text-red-500">*</span></label>
                <input required name="name" value={formData.name} onChange={handleChange} className={`mt-1 w-full rounded-xl border ${errors.name ? 'border-red-500' : 'border-slate-300'} px-4 py-3`} placeholder="Daniel Porta" />
                {errors.name && <p className="text-red-500 text-xs mt-1">{errors.name}</p>}
            </div>
            <div>
                <label className="block text-sm font-semibold">Teléfono / WhatsApp <span className="text-red-500">*</span></label>
                <input required name="phone" value={formData.phone} onChange={handleChange} className={`mt-1 w-full rounded-xl border ${errors.phone ? 'border-red-500' : 'border-slate-300'} px-4 py-3`} placeholder="+34 6XX XXX XXX" />
                {errors.phone && <p className="text-red-500 text-xs mt-1">{errors.phone}</p>}
            </div>
            <div>
                <label className="block text-sm font-semibold">Email</label>
                <input type="email" name="email" value={formData.email} onChange={handleChange} className="mt-1 w-full rounded-xl border border-slate-300 px-4 py-3" placeholder="danielpguti@gmail.com" />
            </div>
            <div>
                <label className="block text-sm font-semibold">Municipio <span className="text-red-500">*</span></label>
                <input required name="city" value={formData.city} onChange={handleChange} className={`mt-1 w-full rounded-xl border ${errors.city ? 'border-red-500' : 'border-slate-300'} px-4 py-3`} placeholder="Santa Eulàlia de Ronçana" />
                {errors.city && <p className="text-red-500 text-xs mt-1">{errors.city}</p>}
            </div>
            
            <div className="md:col-span-2 grid md:grid-cols-3 gap-6">
                 <div>
                    <label className="block text-sm font-semibold">Servicio <span className="text-red-500">*</span></label>
                    <select required name="service" value={formData.service} onChange={handleChange} className={`mt-1 w-full rounded-xl border ${errors.service ? 'border-red-500' : 'border-slate-300'} px-4 py-3`}>
                        <option value="" disabled>Selecciona uno...</option>
                        <option value="mantenimiento">Mantenimiento programado</option>
                        <option value="neumaticos">Cambio de neumáticos a domicilio</option>
                        <option value="recogida">Recogida y entrega (en taller)</option>
                    </select>
                     {errors.service && <p className="text-red-500 text-xs mt-1">{errors.service}</p>}
                </div>
                 <div>
                    <label className="block text-sm font-semibold">Marca y modelo</label>
                    <input name="model" value={formData.model} onChange={handleChange} className="mt-1 w-full rounded-xl border border-slate-300 px-4 py-3" placeholder="VW Golf 1.6 TDI" />
                </div>
                 <div>
                    <label className="block text-sm font-semibold">Matrícula (opcional)</label>
                    <input name="plate" value={formData.plate} onChange={handleChange} className="mt-1 w-full rounded-xl border border-slate-300 px-4 py-3" placeholder="1234-ABC" />
                </div>
            </div>

            <div className="md:col-span-2 grid md:grid-cols-3 gap-6">
                <div>
                    <label className="block text-sm font-semibold">Fecha <span className="text-red-500">*</span></label>
                    <input required type="date" name="date" value={formData.date} onChange={handleChange} className={`mt-1 w-full rounded-xl border ${errors.date ? 'border-red-500' : 'border-slate-300'} px-4 py-3`} />
                    {errors.date && <p className="text-red-500 text-xs mt-1">{errors.date}</p>}
                </div>
                <div>
                    <label className="block text-sm font-semibold">Franja horaria (inicio) <span className="text-red-500">*</span></label>
                    <input required type="time" name="start" value={formData.start} onChange={handleChange} className={`mt-1 w-full rounded-xl border ${errors.start ? 'border-red-500' : 'border-slate-300'} px-4 py-3`} />
                    {errors.start && <p className="text-red-500 text-xs mt-1">{errors.start}</p>}
                </div>
                <div>
                    <label className="block text-sm font-semibold">Franja horaria (fin) <span className="text-red-500">*</span></label>
                    <input required type="time" name="end" value={formData.end} onChange={handleChange} className={`mt-1 w-full rounded-xl border ${errors.end ? 'border-red-500' : 'border-slate-300'} px-4 py-3`} />
                    {errors.end && <p className="text-red-500 text-xs mt-1">{errors.end}</p>}
                </div>
            </div>
            
            <div className="md:col-span-2">
                 <label className="block text-sm font-semibold">Dirección (recogida o servicio) <span className="text-red-500">*</span></label>
                 <input required name="address" value={formData.address} onChange={handleChange} className={`mt-1 w-full rounded-xl border ${errors.address ? 'border-red-500' : 'border-slate-300'} px-4 py-3`} placeholder="C/ Exemplo 123, Santa Eulàlia de Ronçana" />
                 {errors.address && <p className="text-red-500 text-xs mt-1">{errors.address}</p>}
            </div>

            <div className="md:col-span-2 grid md:grid-cols-2 gap-6">
                <label className="inline-flex items-start gap-3 text-sm text-slate-700">
                    <input type="checkbox" name="replacementCar" checked={formData.replacementCar} onChange={handleChange} className="mt-1 rounded border-slate-300" />
                    <span>Necesito <strong>coche de sustitución</strong> si hay retraso por vuestra causa.</span>
                </label>
                <label className="inline-flex items-start gap-3 text-sm text-slate-700">
                    <input type="checkbox" name="accept" required checked={formData.accept} onChange={handleChange} className={`mt-1 rounded ${errors.accept ? 'border-red-500' : 'border-slate-300'}`} />
                    <span>Acepto los <a href="#" className="underline">términos</a> y la <a href="#" className="underline">política de puntualidad</a>. <span className="text-red-500">*</span></span>
                     {errors.accept && <p className="text-red-500 text-xs mt-1">{errors.accept}</p>}
                </label>
            </div>
            
             <div className="md:col-span-2">
                <button type="submit" className="inline-flex px-5 py-3 rounded-xl bg-slate-900 text-white font-semibold">Enviar reserva</button>
            </div>
        </form>
    );
};

export default BookingForm;
