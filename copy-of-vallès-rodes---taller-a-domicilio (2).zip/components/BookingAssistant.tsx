
import React, { useState, useEffect, useRef } from 'react';
import type { Message, ToolCall } from '../types';
import { generateGoogleCalendarLink } from '../utils';

// API Key provided by the user.
const OPENAI_API_KEY = "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";

const systemPrompt: Message = {
  role: 'system',
  content: `
Eres un asistente de atención al cliente para un servicio de mantenimiento y cambio de neumáticos a domicilio llamado "Daniel Porta". Tu misión es actuar como un miembro del equipo 100% humano, resolviendo dudas y gestionando reservas de manera proactiva, empática y eficiente.

---
**Información y Reglas Clave:**
1.  **Identidad:** Nunca reveles que eres una IA, un modelo de lenguaje o un robot. Si te preguntan directamente si eres un robot, responde que eres parte del equipo de Daniel Porta.
2.  **Tono:** Tu tono debe ser cercano, amable y profesional. Usa un lenguaje natural y conversacional. No uses jerga técnica ni frases que suenen automatizadas.
3.  **Servicios:**
    * **Mantenimiento Programado:** Recogida y entrega del coche para mantenimiento.
        * Cubre Granollers, Mollet, Parets, Lliçà d’Amunt, Lliçà de Vall, La Garriga, La Ametlla, Sant Feliu de Codines, Bigues i Riells y Caldes de Montbui.
        * Precio base: Desde 250 € + recambios.
        * Ventaja principal: Ahorro de tiempo (recogida al trabajo, entrega al salir).
        * Incluye: 30 puntos de control, cambio de aceite y filtros, informe detallado.
    * **Cambio de Neumáticos a Domicilio:** Cambio de neumáticos en casa o en el trabajo.
        * Precio de mano de obra: 60 € por rueda + el neumático.
        * Incluye: Equilibrado.
        * Opciones: 3 gamas de neumáticos (Alta, Óptimo, Económico).
        * Duración estimada: 60-120 minutos.
4.  **Valor Añadido:**
    * **Presupuesto:** Ofrece siempre un precio claro y cerrado antes de iniciar el servicio.
    * **Comodidad:** El servicio está diseñado para ahorrar tiempo al cliente. Enfatiza la recogida y entrega.
    * **Garantía:** Si hay un retraso por nuestra causa, se ofrece un coche de sustitución **gratuito**.
5.  **Flujo de Conversación:**
    * **Detección:** Identifica la necesidad del cliente (mantenimiento, neumáticos, presupuesto, etc.).
    * **Proactividad:** Ofrece soluciones de forma proactiva. Por ejemplo, si hablan de falta de tiempo, menciona la recogida y entrega. Si hablan de precio, menciona las diferentes gamas de neumáticos.
    * **Gestión de Reservas:** Tienes la capacidad de recopilar la información necesaria para una reserva a través del chat, como si estuvieras llenando un formulario.
    * **Cierre:** Siempre que la conversación lo permita, intenta guiar al cliente hacia la reserva o la obtención de un presupuesto.
6.  **Ubicación Base:** Santa Eulàlia de Ronçana. Si el cliente pregunta, puedes mencionarla, pero la cobertura principal es el Vallès Oriental.
`
};

const tools = [
  {
    type: "function",
    function: {
      name: "crear_reserva",
      description: "Crea una nueva reserva de servicio para un cliente. Se debe llamar solo cuando se han recopilado todos los datos necesarios para la reserva.",
      parameters: {
        type: "object",
        properties: {
          nombre_cliente: { type: "string", description: "Nombre completo del cliente." },
          telefono_cliente: { type: "string", description: "Número de teléfono del cliente para la confirmación." },
          email_cliente: { type: "string", description: "Correo electrónico del cliente." },
          tipo_servicio: { type: "string", enum: ["mantenimiento", "cambio_neumaticos"], description: "Tipo de servicio solicitado: 'mantenimiento' o 'cambio_neumaticos'." },
          marca_coche: { type: "string", description: "Marca del vehículo del cliente." },
          modelo_coche: { type: "string", description: "Modelo del vehículo del cliente." },
          matricula_coche: { type: "string", description: "Matrícula del vehículo." },
          ubicacion_servicio: { type: "string", description: "Dirección de recogida del vehículo o lugar donde se realizará el cambio de neumáticos (domicilio o trabajo)." },
          fecha_preferida: { type: "string", description: "Fecha preferida para el servicio en formato YYYY-MM-DD." },
          hora_preferida: { type: "string", description: "Hora o franja horaria preferida para el servicio." },
          detalles_adicionales: { type: "string", description: "Cualquier detalle adicional que el cliente haya mencionado sobre el servicio." }
        },
        required: ["nombre_cliente", "telefono_cliente", "tipo_servicio", "marca_coche", "modelo_coche", "matricula_coche", "ubicacion_servicio"]
      }
    }
  }
];

const BookingAssistant: React.FC = () => {
    const [messages, setMessages] = useState<Message[]>([
         { role: 'assistant', content: '¡Hola! Soy Josebas. Dime qué necesitas para tu coche y te ayudaré a reservar una cita en un momento.' }
    ]);
    const [inputValue, setInputValue] = useState('');
    const [isLoading, setIsLoading] = useState(false);
    const messagesEndRef = useRef<HTMLDivElement>(null);
    const isChatAvailable = !!OPENAI_API_KEY;

    useEffect(() => {
        messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
    }, [messages]);

    const processStream = async (reader: ReadableStreamDefaultReader<Uint8Array>, currentMessages: Message[]): Promise<Message[]> => {
        const decoder = new TextDecoder();
        let assistantResponse = '';
        let toolCallParts: { [key: number]: any } = {};
        let finalMessages = [...currentMessages];
        
        finalMessages.push({ role: 'assistant', content: '' });

        while (true) {
            const { done, value } = await reader.read();
            if (done) break;

            const chunk = decoder.decode(value);
            const lines = chunk.split('\n');

            for (const line of lines) {
                if (line.startsWith('data: ')) {
                    const data = line.substring(6);
                    if (data.trim() === '[DONE]') break;
                    try {
                        const parsed = JSON.parse(data);
                        const delta = parsed.choices[0]?.delta;

                        if (delta?.content) {
                            assistantResponse += delta.content;
                            finalMessages[finalMessages.length - 1].content = assistantResponse;
                            setMessages([...finalMessages]);
                        }

                        if (delta?.tool_calls) {
                            for (const toolCall of delta.tool_calls) {
                                const index = toolCall.index;
                                if (!toolCallParts[index]) toolCallParts[index] = {};
                                if (toolCall.id) toolCallParts[index].id = toolCall.id;
                                if (toolCall.type) toolCallParts[index].type = toolCall.type;
                                if (toolCall.function?.name) toolCallParts[index].function_name = toolCall.function.name;
                                if (toolCall.function?.arguments) {
                                    if (!toolCallParts[index].function_arguments) toolCallParts[index].function_arguments = '';
                                    toolCallParts[index].function_arguments += toolCall.function.arguments;
                                }
                            }
                        }
                    } catch (jsonError) {
                        console.error('Error parsing stream data:', jsonError);
                    }
                }
            }
        }

        if (Object.keys(toolCallParts).length > 0) {
            const finalToolCalls: ToolCall[] = Object.values(toolCallParts).map(part => ({
                id: part.id,
                type: 'function',
                function: { name: part.function_name, arguments: part.function_arguments }
            }));

            const assistantMessageWithToolCall: Message = { role: 'assistant', content: null, tool_calls: finalToolCalls };
            finalMessages[finalMessages.length - 1] = assistantMessageWithToolCall;
            setMessages([...finalMessages]);
            return finalMessages;
        }
        
        return finalMessages;
    };

    const handleSendMessage = async (e: React.FormEvent) => {
        e.preventDefault();
        if (!inputValue.trim() || isLoading || !isChatAvailable) return;

        const userMessage: Message = { role: 'user', content: inputValue };
        const newMessages = [...messages, userMessage];
        setMessages(newMessages);
        setInputValue('');
        setIsLoading(true);

        try {
            const response = await fetch('https://api.openai.com/v1/chat/completions', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json', 'Authorization': `Bearer ${OPENAI_API_KEY}` },
                body: JSON.stringify({
                    model: 'gpt-3.5-turbo',
                    messages: [systemPrompt, ...newMessages.slice(1)], // Exclude initial prompt
                    stream: true,
                    tools: tools,
                    tool_choice: "auto",
                }),
            });

            if (!response.ok) {
              const errorBody = await response.json();
              throw new Error(JSON.stringify(errorBody));
            }
            const reader = response.body?.getReader();
            if (!reader) throw new Error('Failed to get response reader');

            let messagesAfterStream = await processStream(reader, newMessages);
            
            const lastMessage = messagesAfterStream[messagesAfterStream.length - 1];
            if (lastMessage?.tool_calls) {
                const toolCall = lastMessage.tool_calls[0];
                const functionArgs = JSON.parse(toolCall.function.arguments);
                
                const toolResponseMessage: Message = {
                    role: 'tool',
                    tool_call_id: toolCall.id,
                    name: toolCall.function.name,
                    content: JSON.stringify({ status: "success", message: `Reserva para ${functionArgs.nombre_cliente} confirmada.` })
                };
                
                const historyForFinalResponse = [...messagesAfterStream, toolResponseMessage];
                setMessages(historyForFinalResponse);

                const finalApiResponse = await fetch('https://api.openai.com/v1/chat/completions', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json', 'Authorization': `Bearer ${OPENAI_API_KEY}` },
                    body: JSON.stringify({
                        model: 'gpt-3.5-turbo',
                        messages: [systemPrompt, ...historyForFinalResponse.slice(1)],
                        stream: true,
                    }),
                });
                
                const finalReader = finalApiResponse.body?.getReader();
                if (!finalReader) throw new Error('Failed to get final response reader');

                const finalMessages = await processStream(finalReader, historyForFinalResponse);
                
                const calendarLink = generateGoogleCalendarLink(functionArgs);
                const calendarMessage: Message = {
                  role: 'assistant',
                  content: `¡Perfecto! He agendado tu cita. Puedes añadirla a tu calendario aquí: [Añadir a Google Calendar](${calendarLink})`
                };
                setMessages([...finalMessages, calendarMessage]);

            }

        } catch (e) {
            console.error("Error communicating with OpenAI:", e);
            let errorMessage = "Lo siento, ha ocurrido un error. Por favor, inténtalo de nuevo.";
            try {
              const parsedError = JSON.parse((e as Error).message);
              if (parsedError?.error?.message) {
                  errorMessage = `Error: ${parsedError.error.message}`;
              }
            } catch {}
            setMessages(prev => [...prev, { role: 'assistant', content: errorMessage }]);
        } finally {
            setIsLoading(false);
        }
    };
    
    const renderMessageContent = (msg: Message) => {
      if (msg.content) {
        const urlRegex = /\[([^\]]+)\]\((https?:\/\/[^\s)]+)\)/g;
        const parts = msg.content.split(urlRegex);
        return parts.map((part, i) => {
          if (i % 3 === 1) { // This is the link text
            const href = parts[i + 1];
            return <a key={i} href={href} target="_blank" rel="noopener noreferrer" className="text-emerald-600 underline font-semibold">{part}</a>;
          }
          if (i % 3 === 2) return null; // This is the URL, already used in the anchor tag
          return part;
        });
      }
      if (msg.tool_calls) {
        return <span className="text-sm italic text-slate-500">Procesando reserva...</span>;
      }
      return <span className="animate-pulse">...</span>;
    };


    return (
        <div className="h-[70vh] max-h-[700px] bg-white rounded-2xl shadow-inner flex flex-col border border-slate-200">
            <div className="flex-1 p-4 overflow-y-auto bg-slate-50">
                <div className="space-y-4">
                {messages.map((msg, index) => (
                    msg.role !== 'tool' && msg.role !== 'system' && (
                        <div key={index} className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}>
                        <div className={`max-w-[80%] rounded-2xl px-4 py-2 whitespace-pre-wrap ${msg.role === 'user' ? 'bg-slate-900 text-white rounded-br-none' : 'bg-slate-200 text-slate-800 rounded-bl-none'}`}>
                            {renderMessageContent(msg)}
                        </div>
                        </div>
                    )
                ))}
                <div ref={messagesEndRef} />
                </div>
            </div>

            <div className="p-4 border-t border-slate-200 bg-white rounded-b-2xl">
                {!isChatAvailable && <p className="text-red-500 text-xs text-center mb-2">El asistente no está disponible.</p>}
                <form onSubmit={handleSendMessage} className="flex gap-2">
                <input
                    type="text"
                    value={inputValue}
                    onChange={(e) => setInputValue(e.target.value)}
                    placeholder={!isChatAvailable ? "El chat no está disponible" : "Ej: Quiero cambiar las ruedas de mi coche..."}
                    className="flex-1 w-full rounded-xl border border-slate-300 px-4 py-3 focus:outline-none focus:ring-2 focus:ring-emerald-500 disabled:bg-slate-100"
                    disabled={isLoading || !isChatAvailable}
                />
                <button
                    type="submit"
                    className="px-4 py-3 rounded-xl bg-slate-900 text-white font-semibold disabled:bg-slate-400"
                    disabled={isLoading || !inputValue.trim() || !isChatAvailable}
                    aria-label="Enviar mensaje"
                >
                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" className="w-6 h-6">
                    <path d="M3.478 2.404a.75.75 0 0 0-.926.941l2.432 7.905H13.5a.75.75 0 0 1 0 1.5H4.984l-2.432 7.905a.75.75 0 0 0 .926.94 60.519 60.519 0 0 0 18.445-8.986.75.75 0 0 0 0-1.218A60.517 60.517 0 0 0 3.478 2.404Z" />
                    </svg>
                </button>
                </form>
            </div>
        </div>
    );
};

export default BookingAssistant;
