
import React, { useState } from 'react';
import BookingForm from './BookingForm';
import BookingAssistant from './BookingAssistant';

type BookingMode = 'form' | 'assistant';

const BookingSection: React.FC = () => {
    const [mode, setMode] = useState<BookingMode>('form');

    const activeTabClasses = 'bg-white border-slate-200 shadow-sm';
    const inactiveTabClasses = 'bg-slate-50 hover:bg-slate-100 border-transparent';

    return (
        <section id="reserva" className="py-12 md:py-16 border-t border-slate-200/70">
            <div className="container mx-auto px-4">
                <div className="max-w-3xl mx-auto text-center">
                    <h2 className="text-2xl md:text-3xl font-extrabold">Reserva tu franja</h2>
                    <p className="mt-2 text-slate-700">Elige cómo quieres reservar: rellenando el formulario o hablando con nuestro asistente.</p>
                </div>

                <div className="mt-8 max-w-4xl mx-auto">
                    <div className="flex justify-center p-1 bg-slate-100 rounded-xl border border-slate-200">
                        <button
                            onClick={() => setMode('form')}
                            className={`w-1/2 px-4 py-2 text-sm font-semibold rounded-lg border transition-all ${mode === 'form' ? activeTabClasses : inactiveTabClasses}`}
                        >
                            Formulario Manual
                        </button>
                        <button
                            onClick={() => setMode('assistant')}
                            className={`w-1/2 px-4 py-2 text-sm font-semibold rounded-lg border transition-all ${mode === 'assistant' ? activeTabClasses : inactiveTabClasses}`}
                        >
                            Asistente IA
                        </button>
                    </div>

                    <div className="mt-6">
                        {mode === 'form' ? <BookingForm /> : <BookingAssistant />}
                    </div>
                </div>
            </div>
        </section>
    );
};

export default BookingSection;
