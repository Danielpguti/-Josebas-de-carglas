
interface BookingDetails {
    nombre_cliente: string;
    tipo_servicio: string;
    marca_coche: string;
    modelo_coche: string;
    matricula_coche: string;
    ubicacion_servicio: string;
    fecha_preferida: string;
    hora_preferida: string;
}

export const generateGoogleCalendarLink = (details: BookingDetails): string => {
    const {
        nombre_cliente,
        tipo_servicio,
        marca_coche,
        modelo_coche,
        matricula_coche,
        ubicacion_servicio,
        fecha_preferida,
        hora_preferida,
    } = details;

    const serviceText = tipo_servicio === 'mantenimiento' ? 'Mantenimiento' : 'Cambio de Neumáticos';
    const title = `Reserva: ${serviceText} - ${nombre_cliente} (${marca_coche} ${modelo_coche})`;
    
    // Attempt to parse date and time
    let startDate, endDate;
    try {
        const [startTime, endTime] = hora_preferida.split(/[\s-]+/).filter(Boolean);
        const startISO = `${fecha_preferida}T${startTime}:00`;
        const endISO = `${fecha_preferida}T${endTime || startTime}:00`;

        startDate = new Date(startISO).toISOString().replace(/-|:|\.\d\d\d/g, "");
        endDate = new Date(endISO).toISOString().replace(/-|:|\.\d\d\d/g, "");
         // If end time wasn't provided, add 1 hour to start time
        if (!endTime) {
            const tempDate = new Date(startISO);
            tempDate.setHours(tempDate.getHours() + 1);
            endDate = tempDate.toISOString().replace(/-|:|\.\d\d\d/g, "");
        }
    } catch(e) {
        // Fallback for non-standard time formats
        const justDate = fecha_preferida.replace(/-/g, "");
        startDate = `${justDate}`;
        endDate = `${justDate}`;
    }

    const description = [
        `Cliente: ${nombre_cliente}`,
        `Servicio: ${serviceText}`,
        `Vehículo: ${marca_coche} ${modelo_coche}`,
        `Matrícula: ${matricula_coche}`,
        `Hora: ${hora_preferida}`,
        `Ubicación: ${ubicacion_servicio}`
    ].join('\\n');

    const params = new URLSearchParams({
        action: 'TEMPLATE',
        text: title,
        dates: `${startDate}/${endDate}`,
        details: description,
        location: ubicacion_servicio,
    });

    return `https://www.google.com/calendar/render?${params.toString()}`;
};
